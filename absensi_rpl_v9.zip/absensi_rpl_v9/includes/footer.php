</div>
<footer class="rpl-footer">
 <span><b>ABSENSI RPL</b> <span class="rpl-footer-sep">•</span> Sistem Informasi Kehadiran</span>
 <span>SMK LUGINA RANCAEKEK <span class="rpl-footer-sep">•</span> <?= date('Y') ?></span>
</footer>
</main>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="<?= url('assets/js/app.js?v=10.1.1') ?>"></script>
<script src="<?= url('assets/js/motion.js?v=10.1.1') ?>"></script>
<script>
(() => {
 const btn=document.getElementById('rplMenuToggle'), side=document.getElementById('rplSidebar');
 if(btn && side) btn.addEventListener('click',()=>{side.classList.toggle('is-open');document.body.classList.toggle('rpl-menu-open',side.classList.contains('is-open'));});
 document.addEventListener('click',e=>{if(window.innerWidth<=900 && side && side.classList.contains('is-open') && !side.contains(e.target) && !btn.contains(e.target)){side.classList.remove('is-open');document.body.classList.remove('rpl-menu-open');}});
})();
</script>
</body>
</html>
