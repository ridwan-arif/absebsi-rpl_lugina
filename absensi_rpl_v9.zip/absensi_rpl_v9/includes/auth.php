<?php
if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/../config/database.php';
if (empty($_SESSION['user_id'])) redirect('auth/login.php');
function require_role(array $roles): void {
    if (!in_array($_SESSION['role'] ?? '', $roles, true)) { http_response_code(403); exit('Akses ditolak.'); }
}
csrf_check();
