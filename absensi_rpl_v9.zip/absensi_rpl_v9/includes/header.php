<?php
if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . '/functions.php';
$isPklStudent = !empty($_SESSION['pkl_student_id']);
$isPklCoordinator = !empty($_SESSION['pkl_group_id']);
$role = $isPklCoordinator ? 'koordinator-pkl' : ($isPklStudent ? 'siswa-pkl' : ($_SESSION['role'] ?? ''));
$title = $page_title ?? 'Dashboard';
$home = $role==='admin' ? 'admin/dashboard.php' : ($isPklCoordinator ? 'pkl/coordinator.php' : ($isPklStudent ? 'pkl/dashboard.php' : 'petugas/dashboard.php'));
$menu = $role==='admin' ? [
 ['admin/dashboard.php','grid-1x2','Dashboard'],['admin/students.php','people','Data Siswa'],['admin/classes.php','collection','Data Kelas'],
 ['admin/users.php','person-gear','Pengguna'],['admin/teachers.php','person-badge','Guru & Tanda Tangan'],['admin/attendance.php','clipboard-check','Koreksi Kehadiran'],['admin/sessions.php','calendar-check','Sesi Absensi'],
 ['admin/reports.php','clipboard-data','Laporan Sekolah'],['admin/pkl_companies.php','building','Perusahaan PKL'],['admin/pkl_groups.php','people','Kelompok & Akun Koordinator'],['admin/pkl_reports.php','geo-alt','Laporan Absensi PKL'],['admin/pkl_control.php','sliders','Manajemen PKL'],['admin/activity.php','clock-history','Log Aktivitas'],['admin/settings.php','gear','Pengaturan']
] : ($isPklCoordinator ? [
 ['pkl/coordinator.php','geo-alt','Absensi PKL Kelompok'],['pkl/coordinator_history.php','journal-text','Riwayat Absensi Kelompok']
] : ($isPklStudent ? [
 ['pkl/dashboard.php','geo-alt','Absensi PKL'],['pkl/history.php','journal-text','Riwayat PKL'],['pkl/password.php','key','Ganti Password']
] : [
 ['petugas/dashboard.php','grid-1x2','Dashboard'],['petugas/scan.php','qr-code-scan','Pindai QR'],
 ['petugas/manual.php','keyboard','Absensi Manual'],['petugas/history.php','journal-text','Riwayat Hari Ini']
]));
$current = basename($_SERVER['PHP_SELF'] ?? '');
$displayName = $_SESSION['pkl_coordinator_name'] ?? ($_SESSION['pkl_student_name'] ?? ($_SESSION['full_name'] ?? 'Pengguna'));
$now = new DateTimeImmutable('now', new DateTimeZone('Asia/Jakarta'));
?>
<!doctype html>
<html lang="id">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= e($title) ?> | <?= e(APP_NAME) ?> v<?= e(APP_VERSION) ?></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
<link href="<?= url('assets/css/app.css?v=10.1.7') ?>" rel="stylesheet">
<link href="<?= url('assets/css/motion.css?v=10.1.7') ?>" rel="stylesheet">
<link href="<?= url('assets/css/table-hover-fix.css?v=10.1.7') ?>" rel="stylesheet">
<link href="<?= url('assets/css/sidebar-icons.css?v=10.1.7') ?>" rel="stylesheet">
</head>
<body class="rpl-shell">
<aside class="rpl-sidebar" id="rplSidebar">
 <a class="rpl-side-brand" href="<?= url($home) ?>">
  <span class="rpl-brand-mark"><img src="<?= url('assets/img/logo-rpl.png') ?>" alt="Logo RPL"></span>
  <span><strong>REKAYASA</strong><small>PERANGKAT LUNAK</small></span>
 </a>
 <div class="rpl-side-caption" aria-hidden="true">MENU UTAMA</div>
 <nav class="rpl-side-nav" aria-label="Navigasi utama">
 <?php foreach($menu as [$path,$icon,$label]): $active = basename($path)===$current; ?>
  <a class="rpl-side-link <?= $active?'active':'' ?>" href="<?= url($path) ?>" title="<?= e($label) ?>" aria-label="<?= e($label) ?>" <?= $active?'aria-current="page"':'' ?>>
   <i class="bi bi-<?= e($icon) ?>" aria-hidden="true"></i><span><?= e($label) ?></span>
  </a>
 <?php endforeach; ?>
 </nav>
 <div class="rpl-side-bottom">
  <div class="rpl-side-version" title="ABSENSI RPL V10.1" aria-label="ABSENSI RPL V10.1"><span class="rpl-status-dot"></span> ABSENSI RPL <b>V10.1</b></div>
  <a class="rpl-side-logout" href="<?= url('auth/logout.php') ?>" title="Keluar" aria-label="Keluar" data-confirm="Yakin ingin keluar dari ABSENSI RPL?"><i class="bi bi-box-arrow-left"></i><span>Keluar</span></a>
 </div>
</aside>
<div class="rpl-main-column">
 <header class="rpl-header">
  <div class="rpl-header-title"><button class="rpl-menu-toggle" id="rplMenuToggle" type="button" aria-label="Buka menu"><i class="bi bi-list"></i></button><div><span class="rpl-eyebrow">SMK LUGINA RANCAEKEK</span><strong>REKAYASA PERANGKAT LUNAK</strong></div></div>
  <div class="rpl-header-right">
   <div class="rpl-live-clock"><span id="rpl-clock-day"><?= e($now->format('l, d M Y')) ?></span><strong id="rpl-clock-time"><?= e($now->format('H:i:s')) ?></strong><small>WAKTU INDONESIA BARAT</small></div>
   <div class="rpl-user-chip"><span class="rpl-account-avatar"><?= e(strtoupper(substr($displayName,0,1))) ?></span><span><b><?= e($displayName) ?></b><small><?= e(strtoupper($role)) ?></small></span></div>
  </div>
 </header>
 <main class="main-content"><div class="content-wrap"><?php show_flash(); ?>
