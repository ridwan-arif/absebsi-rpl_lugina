<?php
require_once __DIR__ . '/../config/app.php';
function e($value): string { return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8'); }
function url(string $path=''): string { return APP_BASE_URL . '/' . ltrim($path, '/'); }
function redirect(string $path): void { header('Location: ' . url($path)); exit; }
function csrf_token(): string {
    if (empty($_SESSION['_csrf'])) $_SESSION['_csrf'] = bin2hex(random_bytes(32));
    return $_SESSION['_csrf'];
}
function csrf_check(): void {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $token = $_POST['_csrf'] ?? '';
        if (!is_string($token) || !hash_equals($_SESSION['_csrf'] ?? '', $token)) {
            http_response_code(419); exit('Token keamanan tidak valid. Muat ulang halaman.');
        }
    }
}
function flash(string $type, string $message): void { $_SESSION['_flash'] = [$type, $message]; }
function show_flash(): void {
    if (!empty($_SESSION['_flash'])) {
        [$type,$message] = $_SESSION['_flash']; unset($_SESSION['_flash']);
        echo '<div class="alert alert-' . e($type) . ' alert-dismissible fade show" role="alert">' . e($message) . '<button class="btn-close" data-bs-dismiss="alert"></button></div>';
    }
}
function log_activity(PDO $pdo, string $action, string $detail=''): void {
    if (empty($_SESSION['user_id'])) return;
    $stmt=$pdo->prepare("INSERT INTO activity_logs(user_id, action, detail, ip_address, created_at) VALUES(?,?,?,?,NOW())");
    $stmt->execute([$_SESSION['user_id'],$action,$detail,$_SERVER['REMOTE_ADDR'] ?? null]);
}
function active_session(PDO $pdo): ?array {
    // Tutup sesi yang tanggalnya sudah lewat atau waktu akhirnya sudah tercapai.
    $pdo->exec("UPDATE attendance_sessions
        SET status='closed', updated_at=NOW()
        WHERE status='active'
          AND (attendance_date < CURDATE()
               OR (attendance_date = CURDATE() AND end_time <= CURTIME()))");

    // Hanya sesi yang sedang berada dalam rentang waktu yang dianggap aktif.
    $q = $pdo->query("SELECT * FROM attendance_sessions
        WHERE attendance_date=CURDATE()
          AND status='active'
          AND start_time <= CURTIME()
          AND end_time > CURTIME()
        ORDER BY id DESC LIMIT 1");
    $row = $q->fetch();
    return $row ?: null;
}

function record_attendance(PDO $pdo, string $token, int $sessionId, string $type, string $method): array {
    if (!in_array($type, ['auto', 'arrival', 'departure'], true)) return ['ok'=>false,'message'=>'Jenis absensi tidak valid.'];
    if (!in_array($method, ['qr','manual'], true)) return ['ok'=>false,'message'=>'Metode absensi tidak valid.'];
    $pdo->beginTransaction();
    try {
        $q=$pdo->prepare("SELECT s.*,c.class_name FROM students s JOIN classes c ON c.id=s.class_id WHERE s.qr_token=? AND s.status='active' FOR UPDATE");
        $q->execute([$token]); $student=$q->fetch();
        if(!$student){$pdo->rollBack();return ['ok'=>false,'message'=>'QR tidak ditemukan atau siswa nonaktif.'];}
        $q=$pdo->prepare("SELECT * FROM attendance_sessions WHERE id=? AND attendance_date=CURDATE() AND status='active' AND start_time<=CURTIME() AND end_time>CURTIME() FOR UPDATE");
        $q->execute([$sessionId]); $session=$q->fetch();
        if(!$session){$pdo->rollBack();return ['ok'=>false,'message'=>'Sesi tidak aktif atau waktunya sudah berakhir.'];}
        // Jenis sesi disetel admin pada nama sesi: [Datang] atau [Pulang]. Sesi lama tanpa penanda dianggap Datang.
        $sessionName=(string)$session['session_name'];
        $sessionType=(preg_match('/\bpulang\b/i',$sessionName))?'departure':'arrival';
        if($type==='auto') $type=$sessionType;
        elseif($type!==$sessionType){$pdo->rollBack();return ['ok'=>false,'message'=>'Jenis absensi mengikuti pengaturan sesi oleh admin.'];}
        $q=$pdo->prepare('SELECT * FROM attendances WHERE student_id=? AND session_id=? FOR UPDATE');
        $q->execute([$student['id'],$sessionId]); $attendance=$q->fetch();
        $field=$type==='arrival'?'arrival_at':'departure_at'; $methodField=$type==='arrival'?'arrival_method':'departure_method';
        if($attendance && !empty($attendance[$field])){$pdo->rollBack();return ['ok'=>false,'duplicate'=>true,'message'=>$type==='arrival'?'Sudah melakukan absen datang.':'Sudah melakukan absen pulang.'];}
        if($type==='departure' && (!$attendance || empty($attendance['arrival_at']))){$check=$pdo->prepare("SELECT a.id FROM attendances a JOIN attendance_sessions s ON s.id=a.session_id WHERE a.student_id=? AND s.attendance_date=? AND a.arrival_at IS NOT NULL AND s.session_name NOT LIKE '%Pulang%' LIMIT 1 FOR UPDATE");$check->execute([$student['id'],$session['attendance_date']]);if(!$check->fetchColumn()){$pdo->rollBack();return ['ok'=>false,'message'=>'Siswa belum tercatat absen datang pada hari ini.'];}}
        $now=date('Y-m-d H:i:s');
        if($attendance){$pdo->prepare("UPDATE attendances SET {$field}=?,{$methodField}=?,updated_at=NOW() WHERE id=?")->execute([$now,$method,$attendance['id']]);$attendanceId=(int)$attendance['id'];}
        else {$pdo->prepare("INSERT INTO attendances(student_id,session_id,{$field},{$methodField},attendance_status,created_at,updated_at) VALUES(?,?,?,?, 'present',NOW(),NOW())")->execute([$student['id'],$sessionId,$now,$method]);$attendanceId=(int)$pdo->lastInsertId();}
        $pdo->commit();
        require_once __DIR__.'/../config/sheets.php';
        $payload=['event_id'=>'att-'.$attendanceId.'-'.$type,'recorded_at'=>$now,'date'=>date('Y-m-d'),'time'=>date('H:i:s'),'student_id'=>(int)$student['id'],'id_rpl'=>$student['nis'],'student_name'=>$student['full_name'],'class_name'=>$student['class_name'],'session_name'=>$sessionName,'attendance_type'=>$type==='arrival'?'Datang':'Pulang','method'=>$method,'operator'=>$_SESSION['full_name']??'Petugas'];
        $queueId=queue_sheet_event($pdo,$attendanceId,$payload);
        // Real-time: kirim absensi ini langsung ke Google Sheets; bila berhasil, kuras sedikit antrean lama.
        try{if(GOOGLE_SHEETS_WEBHOOK!==''&&sync_queue_row($pdo,$queueId)){sync_pending_sheets($pdo,3);}}catch(Throwable $syncError){}
        return ['ok'=>true,'type'=>$type,'message'=>$type==='arrival'?'ABSEN DATANG BERHASIL':'ABSEN PULANG BERHASIL','student'=>$student,'time'=>date('H:i:s',strtotime($now))];
    }catch(Throwable $e){if($pdo->inTransaction())$pdo->rollBack();return ['ok'=>false,'message'=>'Terjadi kesalahan saat menyimpan absensi.'];}
}
