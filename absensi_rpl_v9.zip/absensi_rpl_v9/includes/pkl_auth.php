<?php
if (session_status() === PHP_SESSION_NONE) session_start();
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/functions.php';
function require_pkl_student(): void {
    if (empty($_SESSION['pkl_student_id'])) { header('Location: ' . url('auth/student_login.php')); exit; }
}
function pkl_log(PDO $pdo, string $action, string $detail=''): void {
    $q=$pdo->prepare('INSERT INTO pkl_activity_logs(student_id,action,detail,ip_address) VALUES(?,?,?,?)');
    $q->execute([$_SESSION['pkl_student_id'] ?? null,$action,$detail,$_SERVER['REMOTE_ADDR'] ?? null]);
}
