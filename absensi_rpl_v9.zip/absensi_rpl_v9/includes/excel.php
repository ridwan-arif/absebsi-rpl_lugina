<?php
require_once __DIR__.'/../vendor/autoload.php';
use PhpOffice\PhpSpreadsheet\IOFactory;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use PhpOffice\PhpSpreadsheet\Style\Fill;
use PhpOffice\PhpSpreadsheet\Cell\DataValidation;
function student_template(bool $update=false): void {
    $book=new Spreadsheet(); $sheet=$book->getActiveSheet(); $sheet->setTitle('Data Siswa');
    $headers=['ID RPL','Nama','Kelas','Jabatan','Status'];
    $sheet->fromArray($headers,null,'A1');
    $sheet->getStyle('A2:A500')->getNumberFormat()->setFormatCode('@');
    $sheet->getStyle('A1:E1')->getFont()->setBold(true)->getColor()->setRGB('FFFFFF');
    $sheet->getStyle('A1:E1')->getFill()->setFillType(Fill::FILL_SOLID)->getStartColor()->setRGB('123B78');
    foreach(['A'=>22,'B'=>30,'C'=>18,'D'=>18,'E'=>16] as $col=>$width)$sheet->getColumnDimension($col)->setWidth($width);
    foreach(['C'=> '"X RPL,XI RPL,XII RPL"','D'=>'"Siswa"','E'=>'"Aktif,Nonaktif"'] as $col=>$list){for($row=2;$row<=500;$row++){$v=$sheet->getCell($col.$row)->getDataValidation();$v->setType(DataValidation::TYPE_LIST)->setErrorStyle(DataValidation::STYLE_STOP)->setAllowBlank(false)->setShowErrorMessage(true)->setFormula1($list);}}
    $guide=$book->createSheet();$guide->setTitle('Petunjuk');$guide->fromArray([
      ['PETUNJUK TEMPLATE SISWA'],['1. Jangan mengubah nama kolom pada baris pertama.'],
      ['2. ID RPL wajib diisi dan harus unik. ID RPL dipakai untuk pencarian absensi.'],
      ['3. Untuk update, gunakan ID RPL yang sama; ID RPL baru akan menambah siswa.'],
      ['4. Nama wajib diisi. Kelas hanya X RPL, XI RPL, XII RPL.'],
      ['5. Jabatan wajib Siswa. Status: Aktif atau Nonaktif.'],
      ['6. Isi data mulai baris 2; template sengaja kosong agar tidak ada contoh yang terimpor.'],['7. Impor memvalidasi seluruh baris sebelum menyimpan.']
    ],null,'A1');$guide->getColumnDimension('A')->setWidth(105);$guide->getStyle('A1')->getFont()->setBold(true)->setSize(14);
    header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    header('Content-Disposition: attachment; filename="template-siswa-'.($update?'update':'tambah').'.xlsx"');
    (new Xlsx($book))->save('php://output');exit;
}
function read_student_spreadsheet(string $path): array {
    $book=IOFactory::load($path);$sheet=$book->getSheetByName('Data Siswa')??$book->getActiveSheet();
    $rows=$sheet->toArray(null,true,true,false);$expected=['ID RPL','Nama','Kelas','Jabatan','Status'];
    if(array_map(fn($x)=>trim((string)$x),$rows[0]??[])!==$expected)throw new RuntimeException('Header kolom tidak sesuai template V10.1.');
    return array_slice($rows,1);
}
