<?php
require_once __DIR__.'/../includes/auth.php'; require_role(['admin']);
if($_SERVER['REQUEST_METHOD']==='POST' && isset($_POST['delete_id'])) {
 $id=(int)$_POST['delete_id'];
 try{$pdo->prepare('DELETE FROM students WHERE id=?')->execute([$id]);log_activity($pdo,'DELETE_STUDENT','ID '.$id);flash('success','Siswa dihapus.');}
 catch(PDOException $e){$pdo->prepare("UPDATE students SET status='inactive',updated_at=NOW() WHERE id=?")->execute([$id]);log_activity($pdo,'ARCHIVE_STUDENT','ID '.$id);flash('warning','Siswa memiliki riwayat absensi; diarsipkan menjadi nonaktif.');}
 require_once __DIR__.'/../config/sheets.php';try{sync_student_roster_to_sheets($pdo);}catch(Throwable $ignored){}
 redirect('admin/students.php');
}
$search=trim((string)($_GET['q']??''));$classFilter=(int)($_GET['class_id']??0);
$classes=$pdo->query("SELECT * FROM classes ORDER BY FIELD(class_name,'X RPL','XI RPL','XII RPL')")->fetchAll();
$sql="SELECT s.*,c.class_name FROM students s JOIN classes c ON c.id=s.class_id WHERE (s.nis LIKE ? OR s.full_name LIKE ?)";$params=["%$search%","%$search%"];
if($classFilter){$sql.=' AND s.class_id=?';$params[]=$classFilter;}$sql.=' ORDER BY c.id,s.full_name LIMIT 1000';
$q=$pdo->prepare($sql);$q->execute($params);$rows=$q->fetchAll();
$page_title='Data Siswa';require __DIR__.'/../includes/header.php'; ?>
<div class="page-heading"><div><h1 class="page-title">Manajemen Siswa</h1><p class="page-subtitle">Halaman utama hanya menampilkan data siswa.</p></div><div class="d-flex gap-2 flex-wrap"><a class="btn btn-primary" href="student_form.php"><i class="bi bi-plus-lg"></i> Tambah Siswa</a><a class="btn btn-outline-primary" href="student_import_page.php"><i class="bi bi-file-earmark-spreadsheet"></i> Impor / Ekspor</a><a class="btn btn-outline-primary" href="qr_cards.php"><i class="bi bi-qr-code"></i> Kartu QR</a></div></div>
<div class="panel mb-3"><form class="row g-2"><div class="col-md-7"><input class="form-control" name="q" value="<?=e($search)?>" placeholder="Cari ID RPL atau nama siswa"></div><div class="col-md-3"><select class="form-select" name="class_id"><option value="0">Semua kelas</option><?php foreach($classes as $c):?><option value="<?=(int)$c['id']?>" <?=$classFilter===(int)$c['id']?'selected':''?>><?=e($c['class_name'])?></option><?php endforeach;?></select></div><div class="col-md-2"><button class="btn btn-outline-primary w-100">Cari</button></div></form></div>
<div class="panel"><div class="table-responsive"><table class="table align-middle"><thead><tr><th>ID RPL</th><th>Nama</th><th>Kelas</th><th>Status</th><th>Aksi</th></tr></thead><tbody><?php foreach($rows as $r):?><tr><td><?=e($r['nis'])?></td><td class="fw-semibold"><?=e($r['full_name'])?></td><td><?=e($r['class_name'])?></td><td><span class="badge <?=$r['status']==='active'?'text-bg-success':'text-bg-secondary'?>"><?=e($r['status'])?></span></td><td class="text-nowrap"><a class="btn btn-sm btn-outline-primary" href="student_form.php?id=<?=(int)$r['id']?>">Edit</a> <a class="btn btn-sm btn-outline-secondary" href="qr_cards.php?id=<?=(int)$r['id']?>">QR</a> <form method="post" class="d-inline" onsubmit="return confirm('Hapus atau arsipkan siswa ini?')"><input type="hidden" name="_csrf" value="<?=e(csrf_token())?>"><input type="hidden" name="delete_id" value="<?=(int)$r['id']?>"><button class="btn btn-sm btn-outline-danger">Hapus</button></form></td></tr><?php endforeach;?></tbody></table></div><?php if(!$rows):?><div class="empty-state">Belum ada data siswa.</div><?php endif;?></div>
<?php require __DIR__.'/../includes/footer.php'; ?>
