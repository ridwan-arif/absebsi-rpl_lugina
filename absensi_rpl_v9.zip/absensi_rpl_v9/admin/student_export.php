<?php
require_once '../includes/auth.php'; require_role(['admin']); require_once '../includes/excel.php';
use PhpOffice\PhpSpreadsheet\Spreadsheet; use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
$book=new Spreadsheet();$sh=$book->getActiveSheet();$sh->setTitle('Data Siswa');$sh->fromArray(['ID RPL','Nama','Kelas','Jabatan','Status'],null,'A1');
$q=$pdo->query("SELECT s.nis,s.full_name,c.class_name,s.student_role,s.status FROM students s JOIN classes c ON c.id=s.class_id ORDER BY c.id,s.full_name");$i=2;foreach($q as $r)$sh->fromArray([$r['nis'],$r['full_name'],$r['class_name'],$r['student_role'],$r['status']==='active'?'Aktif':'Nonaktif'],null,'A'.$i++);
$sh->getStyle('A1:E1')->getFont()->setBold(true)->getColor()->setRGB('FFFFFF');$sh->getStyle('A1:E1')->getFill()->setFillType('solid')->getStartColor()->setRGB('123B78');foreach(['A'=>22,'B'=>30,'C'=>18,'D'=>15,'E'=>15] as $c=>$w)$sh->getColumnDimension($c)->setWidth($w);
header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');header('Content-Disposition: attachment; filename="data-siswa-rpl-'.date('Ymd').'.xlsx"');(new Xlsx($book))->save('php://output');exit;
