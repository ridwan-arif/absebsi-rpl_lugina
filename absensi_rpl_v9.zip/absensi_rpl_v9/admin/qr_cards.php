<?php
require_once '../includes/auth.php'; require_role(['admin']);
$sql="SELECT s.id,s.nis,s.full_name,s.qr_token,c.class_name FROM students s JOIN classes c ON c.id=s.class_id WHERE s.status='active'";$params=[];
if(isset($_GET['id'])){$sql.=" AND s.id=?";$params[]=(int)$_GET['id'];}$sql.=" ORDER BY c.class_name,s.full_name";
$q=$pdo->prepare($sql);$q->execute($params);$rows=$q->fetchAll();
$page_title='Kartu QR Siswa';require '../includes/header.php'; ?>
<div class="page-heading no-print"><div><h1 class="page-title">Kartu QR Siswa</h1><p class="page-subtitle">QR Code menggunakan token acak; identitas siswa ditampilkan menggunakan ID RPL.</p></div><button class="btn btn-primary" onclick="window.print()"><i class="bi bi-printer"></i> Cetak Kartu</button></div>
<div class="row g-3"><?php foreach($rows as $r): ?><div class="col-6 col-md-4 col-xl-3"><div class="qr-card"><img src="<?= url('assets/img/logo-rpl.png') ?>" style="width:45px;height:42px;object-fit:contain" alt="Logo RPL"><div class="fw-bold mt-1">SMK LUGINA RANCAEKEK</div><div class="small text-muted">REKAYASA PERANGKAT LUNAK</div><div class="qr-code my-3" data-value="<?= e($r['qr_token']) ?>"></div><div class="fw-bold"><?= e($r['full_name']) ?></div><div class="small"><?= e($r['nis']) ?> · <?= e($r['class_name']) ?></div></div></div><?php endforeach; ?></div>
<script src="https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js"></script><script>document.querySelectorAll('.qr-code').forEach(el=>new QRCode(el,{text:el.dataset.value,width:145,height:145}));</script>
<?php require '../includes/footer.php'; ?>