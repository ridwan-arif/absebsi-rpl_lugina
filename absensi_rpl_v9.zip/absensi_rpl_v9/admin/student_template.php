<?php
require_once '../includes/auth.php'; require_role(['admin']);
require_once '../includes/excel.php';
student_template(($_GET['type']??'add')==='update');
