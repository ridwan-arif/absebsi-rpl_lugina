<?php
require_once '../includes/auth.php'; require_role(['admin']);
$rows=$pdo->query("SELECT l.*,u.full_name FROM activity_logs l LEFT JOIN users u ON u.id=l.user_id ORDER BY l.id DESC LIMIT 250")->fetchAll();
$page_title='Log Aktivitas';require '../includes/header.php'; ?>
<div class="page-heading"><div><h1 class="page-title">Log Aktivitas</h1><p class="page-subtitle">Jejak aktivitas login dan perubahan data.</p></div></div><div class="panel"><div class="table-responsive"><table class="table"><thead><tr><th>Waktu</th><th>Pengguna</th><th>Aksi</th><th>Detail</th><th>IP</th></tr></thead><tbody><?php foreach($rows as $r): ?><tr><td><?= e($r['created_at']) ?></td><td><?= e($r['full_name']??'Akun dihapus') ?></td><td><?= e($r['action']) ?></td><td><?= e($r['detail']) ?></td><td><?= e($r['ip_address']) ?></td></tr><?php endforeach; ?></tbody></table></div></div>
<?php require '../includes/footer.php'; ?>