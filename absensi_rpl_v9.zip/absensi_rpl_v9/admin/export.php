<?php
require_once '../includes/auth.php'; require_role(['admin']);
$date=$_GET['date']??date('Y-m-d');$class=(int)($_GET['class_id']??0);
$sql="SELECT se.attendance_date,st.nis AS id_rpl,st.full_name,cl.class_name,se.session_name,a.arrival_at,a.departure_at,a.arrival_method,a.departure_method,a.attendance_status FROM attendances a JOIN students st ON st.id=a.student_id JOIN classes cl ON cl.id=st.class_id JOIN attendance_sessions se ON se.id=a.session_id WHERE se.attendance_date=?";$params=[$date];if($class){$sql.=" AND st.class_id=?";$params[]=$class;}$sql.=" ORDER BY cl.class_name,st.full_name";
$q=$pdo->prepare($sql);$q->execute($params);
header('Content-Type: text/csv; charset=utf-8');header('Content-Disposition: attachment; filename="absensi-rpl-'.$date.'.csv"');
$out=fopen('php://output','w');fwrite($out,"\xEF\xBB\xBF");fputcsv($out,['Tanggal','ID RPL','Nama','Kelas','Sesi','Datang','Pulang','Metode Datang','Metode Pulang','Status']);
while($r=$q->fetch())fputcsv($out,$r);fclose($out);exit;
