<?php
require_once '../includes/auth.php'; require_role(['admin']);
$page_title='Dashboard Admin';
$stats=[
 'students'=>(int)$pdo->query("SELECT COUNT(*) FROM students WHERE status='active'")->fetchColumn(),
 'classes'=>(int)$pdo->query("SELECT COUNT(*) FROM classes")->fetchColumn(),
 'users'=>(int)$pdo->query("SELECT COUNT(*) FROM users WHERE status='active'")->fetchColumn(),
 'today'=>(int)$pdo->query("SELECT COUNT(*) FROM attendances a JOIN attendance_sessions s ON s.id=a.session_id WHERE s.attendance_date=CURDATE() AND a.arrival_at IS NOT NULL")->fetchColumn()
];
$session=active_session($pdo);
require '../includes/header.php'; ?>
<div class="page-heading"><div><h1 class="page-title">Dashboard Administrator</h1><p class="page-subtitle">Pusat kendali sistem kehadiran jurusan RPL.</p></div><span class="badge text-bg-primary p-2">V10.1</span></div>
<section class="rpl-welcome mb-4" aria-label="Sambutan ABSENSI RPL">
  <div class="rpl-welcome-copy">
    <span class="rpl-eyebrow"><i class="bi bi-stars"></i> SISTEM INFORMASI KEHADIRAN</span>
    <h2>Kelola kehadiran dengan <span>lebih mudah.</span></h2>
    <p>Satu ruang kerja untuk data siswa, sesi absensi, laporan sekolah, dan kegiatan PKL.</p>
    <div class="rpl-values"><span>Kreatif</span><i></i><span>Inovatif</span><i></i><span>Kolaboratif</span><i></i><span>Profesional</span></div>
  </div>
  <div class="rpl-welcome-art" aria-hidden="true"><div class="rpl-orbit orbit-one"></div><div class="rpl-orbit orbit-two"></div><div class="rpl-art-core"><img src="<?= url('assets/img/logo-rpl.png') ?>" alt=""></div><span class="art-spark spark-one">✦</span><span class="art-spark spark-two">✧</span></div>
  <div class="rpl-welcome-version">ABSENSI RPL <b>10.1</b><small>CREATE • LEARN • INNOVATE</small></div>
</section>
<div class="row g-3 mb-4"><?php foreach([['Total Siswa',$stats['students'],'people'],['Total Kelas',$stats['classes'],'collection'],['Pengguna Aktif',$stats['users'],'person-check'],['Hadir Hari Ini',$stats['today'],'calendar-check']] as [$label,$value,$icon]): ?><div class="col-6 col-xl-3"><div class="stat-card"><div class="stat-icon"><i class="bi bi-<?= e($icon) ?>"></i></div><div class="stat-label"><?= e($label) ?></div><div class="stat-value"><?= $value ?></div></div></div><?php endforeach; ?></div>
<div class="row g-3"><div class="col-lg-7"><div class="panel h-100"><h5 class="fw-bold">Status sesi hari ini</h5><?php if($session): ?><div class="session-banner mt-3"><strong><?= e($session['session_name']) ?></strong><div class="small text-muted-custom"><?= e($session['start_time']) ?> – <?= e($session['end_time']) ?> · <?= e($session['attendance_date']) ?></div><span class="badge badge-active mt-2">AKTIF</span></div><?php else: ?><div class="empty-state"><i class="bi bi-calendar-x"></i><p class="mb-0 mt-2">Belum ada sesi aktif hari ini.</p><a href="<?= url('admin/sessions.php') ?>">Buat sesi absensi</a></div><?php endif; ?></div></div>
<div class="col-lg-5"><div class="panel h-100"><h5 class="fw-bold mb-3">Akses cepat</h5><div class="d-grid gap-2"><a class="quick-action" href="<?= url('admin/students.php') ?>"><i class="bi bi-person-plus"></i> Kelola data siswa</a><a class="quick-action" href="<?= url('admin/sessions.php') ?>"><i class="bi bi-calendar-plus"></i> Atur sesi absensi</a><a class="quick-action" href="<?= url('admin/reports.php') ?>"><i class="bi bi-file-earmark-spreadsheet"></i> Lihat laporan</a></div></div></div></div>

<?php
$orgGroups=['Kepala Program Keahlian'=>[],'Staf'=>[],'Guru Produktif'=>[],'Wali Kelas'=>[]];
try {
 $staff=$pdo->query('SELECT t.*,c.class_name FROM teachers t LEFT JOIN classes c ON c.id=t.class_id ORDER BY t.full_name')->fetchAll();
 foreach($staff as $person){
  $pos=strtolower(trim((string)$person['position']));
  if(str_contains($pos,'kepala program')) $bucket='Kepala Program Keahlian';
  elseif(str_contains($pos,'staf')) $bucket='Staf';
  elseif(str_contains($pos,'wali kelas')) $bucket='Wali Kelas';
  elseif(str_contains($pos,'produktif') || str_contains($pos,'mata pelajaran') || $pos==='guru') $bucket='Guru Produktif';
  else continue;
  $orgGroups[$bucket][]=$person;
 }
} catch(Throwable $e) { $staffUnavailable=true; }
?>
<section class="panel mt-4">
 <div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-3">
  <div><h5 class="fw-bold mb-1">Struktur Organisasi Jurusan RPL</h5><p class="text-muted mb-0 small">Data ditarik langsung dari menu Guru & Tenaga Pendidik.</p></div>
  <a class="btn btn-outline-primary btn-sm" href="<?=url('admin/teachers.php')?>"><i class="bi bi-people"></i> Kelola Data Guru</a>
 </div>
 <?php if(!empty($staffUnavailable)):?><div class="alert alert-warning mb-0">Data guru belum dapat dibaca. Periksa ketersediaan tabel guru.</div><?php else:?>
 <div class="org-grid">
 <?php foreach($orgGroups as $group=>$people):?><article class="org-group"><h6><?=e($group)?></h6><?php if(!$people):?><p class="text-muted small mb-0">Belum ada data. Tambahkan melalui menu Guru.</p><?php else:foreach($people as $person):?><div class="org-person"><span class="org-avatar"><i class="bi bi-person-badge"></i></span><span><strong><?=e($person['full_name'])?></strong><small><?=e($person['position'])?><?=!empty($person['class_name'])?' · '.e($person['class_name']):''?></small></span></div><?php endforeach;endif;?></article><?php endforeach;?>
 </div><?php endif;?>
</section>
<?php require '../includes/footer.php'; ?>