<?php
require_once '../includes/auth.php'; require_role(['admin']); require_once '../config/sheets.php';

function dbg_call(array $payload): array {
 $payload['secret']=GOOGLE_SHEETS_SECRET;
 $out=['http'=>0,'curl_error'=>'','body'=>'','final_url'=>'','curl'=>function_exists('curl_init')];
 if(GOOGLE_SHEETS_WEBHOOK===''){$out['curl_error']='GOOGLE_SHEETS_WEBHOOK kosong';return $out;}
 if(!$out['curl']){$out['curl_error']='Ekstensi cURL PHP tidak aktif (aktifkan extension=curl di php.ini lalu restart Apache).';return $out;}
 $ch=curl_init(GOOGLE_SHEETS_WEBHOOK);
 curl_setopt_array($ch,[CURLOPT_POST=>true,CURLOPT_POSTFIELDS=>json_encode($payload,JSON_UNESCAPED_UNICODE),CURLOPT_HTTPHEADER=>['Content-Type: application/json'],
  CURLOPT_RETURNTRANSFER=>true,CURLOPT_FOLLOWLOCATION=>true,CURLOPT_MAXREDIRS=>5,CURLOPT_CONNECTTIMEOUT=>8,CURLOPT_TIMEOUT=>25,
  CURLOPT_SSL_VERIFYPEER=>GOOGLE_SHEETS_SSL_VERIFY,CURLOPT_SSL_VERIFYHOST=>GOOGLE_SHEETS_SSL_VERIFY?2:0]);
 $body=curl_exec($ch);
 $out['http']=(int)curl_getinfo($ch,CURLINFO_HTTP_CODE);$out['final_url']=(string)curl_getinfo($ch,CURLINFO_EFFECTIVE_URL);$out['curl_error']=curl_error($ch);
 curl_close($ch);$out['body']=is_string($body)?$body:'';
 return $out;
}

$result=null;$label='';
if($_SERVER['REQUEST_METHOD']==='POST'){
 csrf_check();
 $a=$_POST['do']??'';
 if($a==='ping'){$label='Tes koneksi (ping)';$result=dbg_call(['action'=>'ping']);}
 if($a==='row'){$label='Kirim 1 baris percobaan ke tab Absensi';$now=date('Y-m-d H:i:s');
  $result=dbg_call(['event_id'=>'test-'.time(),'recorded_at'=>$now,'date'=>date('Y-m-d'),'time'=>date('H:i:s'),'student_id'=>0,'id_rpl'=>'TES','student_name'=>'BARIS PERCOBAAN (boleh dihapus)','class_name'=>'-','session_name'=>'tes','attendance_type'=>'Tes','method'=>'debug','operator'=>$_SESSION['full_name']??'Admin']);}
}
$cnt=$pdo->query("SELECT status,COUNT(*) c FROM sheet_sync_queue GROUP BY status")->fetchAll(PDO::FETCH_KEY_PAIR);
$errs=$pdo->query("SELECT id,attempts,last_error FROM sheet_sync_queue WHERE last_error IS NOT NULL ORDER BY id DESC LIMIT 5")->fetchAll();
$page_title='Diagnosa Google Sheets';require '../includes/header.php';
$decoded=$result?json_decode($result['body'],true):null;
?>
<div class="page-heading"><div><h1 class="page-title">Diagnosa Google Sheets</h1><p class="page-subtitle">Menampilkan jawaban mentah dari Google untuk mencari penyebab data tidak masuk.</p></div></div>
<div class="panel mb-3">
 <h5 class="fw-bold">Konfigurasi terbaca</h5>
 <table class="table mb-0"><tbody>
  <tr><td>Webhook terpasang</td><td><?= GOOGLE_SHEETS_WEBHOOK===''?'TIDAK (kosong)':'Ya - '.e(substr(GOOGLE_SHEETS_WEBHOOK,0,60)).'...'.e(substr(GOOGLE_SHEETS_WEBHOOK,-12)) ?></td></tr>
  <tr><td>Berakhiran /exec</td><td><?= substr(GOOGLE_SHEETS_WEBHOOK,-5)==='/exec'?'Ya':'TIDAK - URL salah' ?></td></tr>
  <tr><td>Token (4 awal / 4 akhir)</td><td><?= e(substr(GOOGLE_SHEETS_SECRET,0,4)) ?>...<?= e(substr(GOOGLE_SHEETS_SECRET,-4)) ?></td></tr>
  <tr><td>ID spreadsheet di website</td><td><?= e(GOOGLE_SHEETS_ID) ?></td></tr>
  <tr><td>cURL PHP aktif</td><td><?= function_exists('curl_init')?'Ya':'TIDAK' ?></td></tr>
  <tr><td>Antrean</td><td>pending: <?= (int)($cnt['pending']??0) ?> | failed: <?= (int)($cnt['failed']??0) ?> | sent: <?= (int)($cnt['sent']??0) ?></td></tr>
 </tbody></table>
</div>
<div class="panel mb-3">
 <form method="post" class="d-flex flex-wrap gap-2"><input type="hidden" name="_csrf" value="<?= e(csrf_token()) ?>">
  <button class="btn btn-outline-primary" name="do" value="ping">1. Tes koneksi (ping)</button>
  <button class="btn btn-primary" name="do" value="row">2. Kirim 1 baris percobaan ke sheet</button>
 </form>
</div>
<?php if($result): ?>
<div class="panel mb-3">
 <h5 class="fw-bold"><?= e($label) ?></h5>
 <table class="table mb-3"><tbody>
  <tr><td>Kode HTTP</td><td><?= (int)$result['http'] ?></td></tr>
  <tr><td>Galat cURL</td><td><?= $result['curl_error']!==''?e($result['curl_error']):'-' ?></td></tr>
  <tr><td>Alamat akhir</td><td style="word-break:break-all"><?= e(substr($result['final_url'],0,120)) ?></td></tr>
  <tr><td>Hasil</td><td><?php
   if(is_array($decoded)&&!empty($decoded['ok'])) echo 'BERHASIL - Apps Script menjawab ok.';
   elseif(is_array($decoded)&&($decoded['error']??'')==='unauthorized') echo 'DITOLAK: token di website berbeda dengan SHARED_SECRET di Apps Script.';
   elseif(is_array($decoded)) echo 'Apps Script galat: '.e($decoded['error']??'tidak diketahui');
   elseif($result['body']==='') echo 'Tidak ada respons.';
   else echo 'Respons BUKAN JSON (kemungkinan halaman login/izin Google: akses belum "Siapa saja" atau belum diotorisasi).';
  ?></td></tr>
 </tbody></table>
 <div class="text-muted-custom small mb-1">Jawaban mentah (500 karakter pertama):</div>
 <pre style="white-space:pre-wrap;word-break:break-all;background:#0e1a2e;color:#cfe3ff;padding:12px;border-radius:10px;max-height:260px;overflow:auto"><?= e(substr($result['body'],0,500)) ?></pre>
</div>
<?php endif; ?>
<?php if($errs): ?>
<div class="panel"><h5 class="fw-bold">Galat terakhir di antrean</h5><ul class="mb-0"><?php foreach($errs as $r): ?><li>#<?= (int)$r['id'] ?> (percobaan <?= (int)$r['attempts'] ?>): <?= e($r['last_error']) ?></li><?php endforeach; ?></ul></div>
<?php endif; ?>
<?php require '../includes/footer.php'; ?>
