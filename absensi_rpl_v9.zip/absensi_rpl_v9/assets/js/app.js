document.addEventListener('click', function (event) {
  const target = event.target.closest('[data-confirm]');
  if (target && !confirm(target.getAttribute('data-confirm') || 'Lanjutkan tindakan ini?')) event.preventDefault();
});

/* V10.1.2 — shared WIB clock for every authenticated role */
(() => {
  const day = document.getElementById('rpl-clock-day');
  const time = document.getElementById('rpl-clock-time');
  if (!day || !time) return;
  const zone = 'Asia/Jakarta';
  const update = () => {
    const now = new Date();
    day.textContent = new Intl.DateTimeFormat('id-ID', {
      timeZone: zone, weekday: 'long', day: '2-digit', month: 'short', year: 'numeric'
    }).format(now);
    const next = new Intl.DateTimeFormat('id-ID', {
      timeZone: zone, hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false
    }).format(now).replace(/\./g, ':');
    if (time.textContent !== next) {
      time.textContent = next;
      time.classList.remove('tick');
      void time.offsetWidth;
      time.classList.add('tick');
    }
  };
  update();
  window.setInterval(update, 1000);
})();
