/* Absensi RPL — motion layer (vanilla JS, tanpa dependensi). Dimuat SETELAH app.js. */
(() => {
  const root = document.documentElement, rm = matchMedia('(prefers-reduced-motion: reduce)').matches;
  const $$ = (s, r = document) => [...r.querySelectorAll(s)];
  root.classList.add('m-js');

  /* ── Reveal bertahap saat masuk layar ── */
  const io = new IntersectionObserver((es) => es.forEach((e) => { if (e.isIntersecting) { e.target.classList.add('m-in'); io.unobserve(e.target); } }), { threshold: .08 });
  $$('.page-heading,.stat-card,.panel,.quick-action,.session-banner,.qr-card').forEach((el, i) => {
    el.classList.add('m-reveal'); el.style.setProperty('--d', Math.min(i, 10) * 60 + 'ms'); io.observe(el);
  });

  /* ── 1. TEXT RIPPLE: .page-title (dekat kursor = melengkung, klik = gelombang) ── */
  $$('.page-title,[data-ripple]').forEach((t) => {
    if (t.children.length) return;
    const text = t.textContent; t.setAttribute('aria-label', text); t.textContent = '';
    const chars = [...text].map((c) => { const s = document.createElement('span'); s.className = 'm-char'; s.setAttribute('aria-hidden', 'true'); s.textContent = c; t.appendChild(s); return s; });
    if (rm) return;
    t.addEventListener('pointermove', (e) => chars.forEach((s) => {
      const r = s.getBoundingClientRect(), d = Math.hypot(e.clientX - r.left - r.width / 2, e.clientY - r.top - r.height / 2);
      const k = Math.exp(-d * d / 4000); s.style.transform = `translateY(${-14 * k}px) scale(${1 + .25 * k})`;
    }));
    t.addEventListener('pointerleave', () => chars.forEach((s) => (s.style.transform = '')));
    t.addEventListener('click', () => chars.forEach((s, i) => s.animate([{ transform: 'translateY(0)' }, { transform: 'translateY(-18px)' }, { transform: 'translateY(0)' }], { duration: 520, delay: i * 35, easing: 'ease-in-out' })));
  });

  /* ── 3. LIQUID TEXT: .stat-value (hitung naik + gradien cair) ── */
  const liquids = $$('.stat-value,[data-liquid]');
  if (liquids.length) {
    const ns = 'http://www.w3.org/2000/svg', svg = document.createElementNS(ns, 'svg');
    svg.setAttribute('width', 0); svg.setAttribute('height', 0); svg.style.position = 'absolute'; svg.setAttribute('aria-hidden', 'true');
    svg.innerHTML = '<filter id="m-liquid" x="-10%" y="-20%" width="120%" height="140%"><feTurbulence type="fractalNoise" baseFrequency=".01 .03" numOctaves="2" result="n"/><feDisplacementMap in="SourceGraphic" in2="n" scale="7"/></filter>';
    document.body.appendChild(svg);
    const turb = svg.querySelector('feTurbulence');
    if (!rm) { let t = 0, last = 0; const tick = (now) => { if (now - last > 40) { last = now; t += .03; const f = .01 + .008 * Math.sin(t); turb.setAttribute('baseFrequency', `${f} ${f * 3}`); } requestAnimationFrame(tick); }; requestAnimationFrame(tick); }
    liquids.forEach((el) => {
      const m = el.textContent.trim().match(/^(\d+)(.*)$/); el.classList.add('m-liquid');
      if (m && !rm) { const end = +m[1], t0 = performance.now(); (function step(n) { const p = Math.min((n - t0) / 900, 1); el.textContent = Math.round(end * (1 - Math.pow(1 - p, 3))) + m[2]; if (p < 1) requestAnimationFrame(step); })(t0); }
    });
  }

  /* ── 5. SEGMENTED CONTROL ── */
  const movePill = (box, pill, target) => { if (!target) return; pill.style.left = target.offsetLeft + 'px'; pill.style.width = target.offsetWidth + 'px'; if (box.classList.contains('sidebar')) { pill.style.top = target.offsetTop + 'px'; pill.style.height = target.offsetHeight + 'px'; } };
  // (a) sidebar: pil mengikuti menu yang di-hover dan kembali ke menu aktif
  const sb = document.querySelector('.sidebar');
  if (sb) {
    const pill = document.createElement('span'); pill.className = 'm-pill'; sb.prepend(pill);
    const act = () => sb.querySelector('.nav-link.active'), home = () => movePill(sb, pill, act());
    $$('.nav-link', sb).forEach((a) => { a.addEventListener('mouseenter', () => movePill(sb, pill, a)); a.addEventListener('focus', () => movePill(sb, pill, a)); });
    sb.addEventListener('mouseleave', home); addEventListener('resize', home); addEventListener('load', home); home();
  }
  // (b) filter: <select data-segmented [data-autosubmit]> otomatis menjadi segmented control
  $$('select[data-segmented]').forEach((sel) => {
    const box = document.createElement('div'), pill = document.createElement('span'); box.className = 'm-seg'; box.setAttribute('role', 'tablist'); pill.className = 'm-pill'; box.appendChild(pill);
    const btns = [...sel.options].map((o) => { const b = document.createElement('button'); b.type = 'button'; b.role = 'tab'; b.textContent = o.text; b.dataset.v = o.value; box.appendChild(b); return b; });
    const sync = () => { btns.forEach((b) => b.setAttribute('aria-selected', b.dataset.v === sel.value)); movePill(box, pill, btns.find((b) => b.dataset.v === sel.value)); };
    btns.forEach((b) => b.addEventListener('click', () => { sel.value = b.dataset.v; sync(); sel.dispatchEvent(new Event('change', { bubbles: true })); if (sel.hasAttribute('data-autosubmit') && sel.form) sel.form.requestSubmit(); }));
    sel.style.display = 'none'; sel.after(box); sync(); addEventListener('resize', sync); addEventListener('load', sync);
  });

  /* ── 2. FORM: validasi real-time + langkah demi langkah ── */
  const MSG = (el) => { const v = el.validity; return v.valueMissing ? 'Wajib diisi.' : v.typeMismatch ? (el.type === 'email' ? 'Format email belum valid.' : 'Format belum valid.') : v.patternMismatch ? (el.title || 'Format belum sesuai.') : v.tooShort ? `Minimal ${el.minLength} karakter.` : v.rangeUnderflow || v.rangeOverflow ? 'Nilai di luar batas.' : 'Isian belum valid.'; };
  const fields = (r) => $$('input.form-control,select.form-select,textarea.form-control', r).filter((e) => e.type !== 'hidden' && e.type !== 'file' && !e.disabled);
  const mark = (el) => {
    const host = el.closest('.input-group') || el; let m = host.nextElementSibling;
    if (!m || !m.classList.contains('m-msg')) { m = document.createElement('div'); m.className = 'm-msg'; m.setAttribute('role', 'alert'); host.after(m); }
    const has = el.value.trim() !== '', ok = el.validity.valid; // validity.valid tidak memicu event 'invalid' (hindari rekursi)
    el.classList.toggle('is-invalid', !ok); el.classList.toggle('is-valid', ok && has);
    m.textContent = ok ? '' : MSG(el); m.classList.toggle('show', !ok); if (host !== el) host.classList.toggle('is-invalid', !ok);
  };
  $$('form:not([data-no-motion])').forEach((f) => {
    const fs = fields(f); if (!fs.length) return;
    fs.forEach((el) => { el.addEventListener('blur', () => { el.dataset.t = 1; mark(el); }); el.addEventListener('input', () => { if (el.dataset.t || el.classList.contains('is-invalid')) mark(el); }); });
    f.addEventListener('invalid', (e) => { e.preventDefault(); e.target.dataset.t = 1; mark(e.target); if (!f.dataset.shook) { f.dataset.shook = 1; f.classList.add('m-shake'); setTimeout(() => { f.classList.remove('m-shake'); delete f.dataset.shook; }, 450); } }, true);
  });
  // wizard: <form class="row g-3" data-steps="3"> membagi isian menjadi langkah, 3 isian per langkah
  $$('form[data-steps]').forEach((f) => {
    const per = +f.dataset.steps || 3, kids = [...f.children].filter((c) => c.type !== 'hidden' && c.tagName !== 'INPUT');
    const submitCol = kids.find((c) => c.querySelector('[type=submit]') || c.matches('[type=submit]')), cols = kids.filter((c) => c !== submitCol);
    if (cols.length <= per) return;
    const n = Math.ceil(cols.length / per), bar = document.createElement('div'), steps = [];
    bar.className = 'm-wiz-bar col-12'; bar.innerHTML = '<i></i>'.repeat(n); f.prepend(bar);
    for (let i = 0; i < n; i++) { const s = document.createElement('div'); s.className = 'm-step col-12'; const row = document.createElement('div'); row.className = 'row g-3'; cols.slice(i * per, (i + 1) * per).forEach((c) => row.appendChild(c)); s.appendChild(row); steps.push(s); submitCol ? submitCol.before(s) : f.appendChild(s); }
    const nav = document.createElement('div'), back = document.createElement('button'), next = document.createElement('button');
    nav.className = 'm-nav-row col-12'; back.type = next.type = 'button'; back.className = 'btn btn-outline-primary'; next.className = 'btn btn-primary'; back.textContent = 'Kembali'; next.textContent = 'Lanjut';
    nav.append(back, next); let cur = 0;
    const show = (i, dir) => { cur = i; steps.forEach((s, k) => { s.classList.toggle('on', k === i); s.classList.toggle('back', dir < 0); }); $$('i', bar).forEach((b, k) => b.classList.toggle('on', k <= i)); back.style.visibility = i ? 'visible' : 'hidden'; next.style.display = i === n - 1 ? 'none' : ''; if (submitCol) submitCol.style.display = i === n - 1 ? '' : 'none'; };
    next.addEventListener('click', () => { const bad = fields(steps[cur]).filter((el) => { el.dataset.t = 1; mark(el); return !el.checkValidity(); }); if (bad.length) { bad[0].focus(); steps[cur].classList.add('m-shake'); setTimeout(() => steps[cur].classList.remove('m-shake'), 450); } else show(cur + 1, 1); });
    back.addEventListener('click', () => show(cur - 1, -1));
    submitCol ? submitCol.before(nav) : f.appendChild(nav); show(0, 1);
  });

  /* ── transisi keluar halaman (tautan internal biasa) ── */
  document.addEventListener('click', (e) => {
    const a = e.target.closest('a[href]'); if (!a || e.defaultPrevented || e.metaKey || e.ctrlKey || e.shiftKey || a.target || a.hasAttribute('download') || a.dataset.confirm !== undefined) return;
    const u = new URL(a.href, location.href); if (u.origin !== location.origin || u.pathname === location.pathname && u.search === location.search || /export|logout|\.pdf|\.xlsx/i.test(u.pathname)) return;
    e.preventDefault(); document.body.classList.add('m-leave'); setTimeout(() => (location.href = a.href), 170);
  });
  addEventListener('pageshow', () => document.body.classList.remove('m-leave'));
})();
