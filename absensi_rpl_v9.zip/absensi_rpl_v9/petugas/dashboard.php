<?php
require_once '../includes/auth.php'; require_role(['petugas','admin']);
$session=active_session($pdo);
$counts=['arrival'=>0,'departure'=>0];
if($session){$q=$pdo->prepare("SELECT SUM(arrival_at IS NOT NULL) a,SUM(departure_at IS NOT NULL) d FROM attendances WHERE session_id=?");$q->execute([$session['id']]);$r=$q->fetch();$counts=['arrival'=>(int)($r['a']??0),'departure'=>(int)($r['d']??0)];}
$page_title='Dashboard Petugas';require '../includes/header.php'; ?>
<div class="page-heading"><div><h1 class="page-title">Dashboard Petugas</h1><p class="page-subtitle">Operasional pencatatan kehadiran siswa RPL.</p></div></div>
<section class="rpl-welcome rpl-welcome-compact mb-4" aria-label="ABSENSI RPL">
  <div class="rpl-welcome-copy">
    <span class="rpl-eyebrow"><i class="bi bi-stars"></i> ABSENSI RPL · VERSI 10.1</span>
    <h2>Fokus pada layanan <span>kehadiran.</span></h2>
    <p>Proses pencatatan siswa secara praktis, rapi, dan terpusat.</p>
    <div class="rpl-values"><span>Kreatif</span><i></i><span>Inovatif</span><i></i><span>Kolaboratif</span><i></i><span>Profesional</span></div>
  </div>
  <div class="rpl-welcome-art" aria-hidden="true"><div class="rpl-orbit orbit-one"></div><div class="rpl-orbit orbit-two"></div><div class="rpl-art-core"><img src="<?= url('assets/img/logo-rpl.png') ?>" alt=""></div></div>
</section>
<?php if($session): ?><div class="session-banner mb-4"><div class="small text-uppercase fw-bold">Sesi aktif dari administrator</div><strong><?= e($session['session_name']) ?></strong> · <?= e($session['attendance_date']) ?> · <?= e(substr($session['start_time'],0,5)) ?>–<?= e(substr($session['end_time'],0,5)) ?></div><?php else: ?><div class="alert alert-warning">Belum ada sesi aktif hari ini. Petugas tidak dapat mencatat absensi sebelum admin mengaktifkan sesi.</div><?php endif; ?>
<div class="row g-3 mb-4"><div class="col-6"><div class="stat-card"><div class="stat-label">Absen datang</div><div class="stat-value"><?= $counts['arrival'] ?></div></div></div><div class="col-6"><div class="stat-card"><div class="stat-label">Absen pulang</div><div class="stat-value"><?= $counts['departure'] ?></div></div></div></div>
<div class="row g-3"><div class="col-md-6"><a class="quick-action h-100" href="<?= url('petugas/scan.php') ?>"><i class="bi bi-qr-code-scan"></i><span>Pindai QR Code siswa</span></a></div><div class="col-md-6"><a class="quick-action h-100" href="<?= url('petugas/manual.php') ?>"><i class="bi bi-keyboard"></i><span>Input absensi manual</span></a></div></div>
<?php require '../includes/footer.php'; ?>