<?php
require_once __DIR__ . '/../includes/auth.php';
require_role(['petugas','admin']);
$session = active_session($pdo);
$page_title = 'Absensi Manual';
require __DIR__ . '/../includes/header.php';
?>
<div class="page-heading"><div><h1 class="page-title">Absensi Manual</h1><p class="page-subtitle">Cari siswa menggunakan ID RPL atau nama, periksa identitas, lalu konfirmasi.</p></div></div>
<?php if (!$session): ?><div class="alert alert-warning">Tidak ada sesi aktif hari ini. Hubungi administrator.</div><?php else: ?>
<div class="session-banner mb-3"><span class="small d-block">SESI AKTIF</span><strong><?= e($session['session_name']) ?></strong> · <?= e(substr($session['start_time'],0,5)) ?>–<?= e(substr($session['end_time'],0,5)) ?></div>
<div class="panel" style="max-width:760px">
<label class="form-label" for="student-search">ID RPL atau nama siswa</label>
<div class="input-group mb-3"><input id="student-search" class="form-control" placeholder="Masukkan ID RPL atau nama siswa..." autocomplete="off"><button type="button" class="btn btn-outline-primary" id="search-btn"><i class="bi bi-search"></i> Cari</button></div>
<div id="search-results" class="list-group mb-3"></div>
<div id="selected-student" class="d-none border rounded-3 p-3 mb-3"><div class="small text-muted">SISWA DIPILIH</div><h5 id="student-name" class="fw-bold mb-1"></h5><div id="student-meta" class="small text-muted mb-3"></div><label class="form-label" for="manual-type">Jenis absensi</label><select id="manual-type" class="form-select mb-3"><option value="arrival">Hadir — Absen Datang</option><option value="departure">Hadir — Absen Pulang</option><option value="sick">Sakit</option><option value="permit">Izin</option><option value="absent">Alfa</option></select><button type="button" class="btn btn-primary w-100" id="confirm-manual">Konfirmasi dan Simpan</button></div>
<div id="manual-result" class="small text-muted" role="status">Pencatatan manual memerlukan konfirmasi petugas.</div></div>
<script>
(() => {
 const input=document.getElementById('student-search'), results=document.getElementById('search-results'), selected=document.getElementById('selected-student'), out=document.getElementById('manual-result'), btn=document.getElementById('confirm-manual');
 let current=null;
 const escapeHtml=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 async function search(){
  const q=input.value.trim(); current=null; selected.classList.add('d-none'); results.innerHTML='';
  if(!q){results.innerHTML='<div class="text-muted small p-2">Masukkan ID RPL atau nama siswa.</div>';return;}
  results.innerHTML='<div class="text-muted small p-2">Mencari siswa...</div>';
  try { const r=await fetch('../api/search_students.php?q='+encodeURIComponent(q),{headers:{'Accept':'application/json'},cache:'no-store'}); const data=await r.json(); results.innerHTML='';
   if(!r.ok || !Array.isArray(data)) throw new Error(data.error||'Respons pencarian tidak valid.');
   if(!data.length){results.innerHTML='<div class="text-muted small p-2">ID RPL atau nama siswa tidak ditemukan / siswa nonaktif.</div>';return;}
   data.forEach(s=>{const b=document.createElement('button');b.type='button';b.className='list-group-item list-group-item-action';b.textContent=s.id_rpl+' · '+s.full_name+' · '+s.class_name;b.addEventListener('click',()=>{current=s;document.getElementById('student-name').textContent=s.full_name;document.getElementById('student-meta').textContent='ID RPL: '+s.id_rpl+' · '+s.class_name;selected.classList.remove('d-none');results.innerHTML='';out.className='small text-muted';out.textContent='Periksa identitas siswa, lalu konfirmasi absensi.';});results.appendChild(b);});
  } catch(e){results.innerHTML='<div class="text-danger small p-2">'+escapeHtml(e.message||'Gagal menghubungi server.')+'</div>';}
 }
 document.getElementById('search-btn').addEventListener('click',search); input.addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();search();}});
 btn.addEventListener('click',async()=>{if(!current)return;if(!confirm('Konfirmasi absensi untuk '+current.full_name+' ('+current.id_rpl+')?'))return;
  btn.disabled=true;btn.textContent='Menyimpan...';out.className='small text-muted';out.textContent='Mengirim data ke server...';
  try{const fd=new FormData();fd.append('token',current.qr_token);fd.append('session_id','<?= (int)$session['id'] ?>');fd.append('type',document.getElementById('manual-type').value);fd.append('method','manual');fd.append('_csrf','<?= e(csrf_token()) ?>');const r=await fetch('../api/manual_attendance.php',{method:'POST',body:fd,headers:{'Accept':'application/json'}});const d=await r.json();if(!r.ok||!d.ok)throw new Error(d.message||'Absensi gagal disimpan.');out.className='text-success fw-bold';out.textContent=d.message+' · '+d.student+' · '+d.time+' · ID RPL '+(d.id_rpl||current.id_rpl);current=null;selected.classList.add('d-none');input.value='';
  }catch(e){out.className='text-danger fw-bold';out.textContent=e.message||'Terjadi kesalahan saat menyimpan absensi.';}finally{btn.disabled=false;btn.textContent='Konfirmasi dan Simpan';}
 });
})();
</script>
<?php endif; ?>
<?php require __DIR__ . '/../includes/footer.php'; ?>
