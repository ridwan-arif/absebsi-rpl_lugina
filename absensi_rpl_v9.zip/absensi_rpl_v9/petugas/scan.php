<?php
require_once '../includes/auth.php'; require_role(['petugas','admin']);
$session=active_session($pdo);$page_title='Pindai QR';require '../includes/header.php'; ?>
<div class="page-heading"><div><h1 class="page-title">Absensi Siswa</h1><p class="page-subtitle">Pindai QR siswa. Jenis datang/pulang mengikuti sesi yang diatur admin.</p></div></div>
<div class="d-flex flex-wrap gap-2 mb-3">
 <a class="btn btn-primary" href="scan.php"><i class="bi bi-camera"></i> Camera</a>
 <a class="btn btn-outline-primary" href="manual.php"><i class="bi bi-keyboard"></i> Manual</a>

</div>
<?php if(!$session): ?><div class="alert alert-warning">Tidak ada sesi aktif hari ini. Silakan hubungi admin.</div><?php else: ?>
<div class="session-banner mb-3"><span class="small d-block">SESI AKTIF</span><strong><?= e($session['session_name']) ?></strong> · <?= e(substr($session['start_time'],0,5)) ?>–<?= e(substr($session['end_time'],0,5)) ?></div>
<input type="hidden" id="session-id" value="<?= (int)$session['id'] ?>">
<div class="panel scan-card" id="camera-panel">
 <h5 class="mb-3"><i class="bi bi-camera"></i> Scan dengan Kamera</h5>
 <div id="qr-reader" class="mb-3"></div>
 <div id="scan-result" class="alert alert-secondary scan-result">Tekan Mulai Kamera satu kali. Kamera akan tetap aktif untuk pemindaian berikutnya.</div>
 <button class="btn btn-primary w-100" id="start-scan"><i class="bi bi-camera"></i> Mulai Kamera</button>
 <p class="small text-muted mt-3 mb-0 text-center">Gunakan localhost atau HTTPS dan izinkan akses kamera browser.</p>
</div>
<?php endif; ?>
<script src="https://unpkg.com/html5-qrcode"></script><script>
(()=>{const sid=document.getElementById('session-id');if(!sid)return;const sessionId=sid.value,csrf='<?= e(csrf_token()) ?>',start=document.getElementById('start-scan'),out=document.getElementById('scan-result');let scanner=null,busy=false,lastToken='',lastAt=0;
async function submitToken(token){if(busy)return;busy=true;out.className='alert alert-info scan-result';out.textContent='QR terbaca. Memeriksa status absensi...';try{const fd=new FormData();fd.append('token',token);fd.append('session_id',sessionId);fd.append('type','auto');fd.append('method','qr');fd.append('_csrf',csrf);const res=await fetch('../api/attendance.php',{method:'POST',body:fd,headers:{'Accept':'application/json'}});const d=await res.json();out.className='alert '+(d.ok?'alert-success':(d.duplicate?'alert-warning':'alert-danger'))+' scan-result';out.textContent=d.ok?`${d.message} · ${d.student} · ${d.id_rpl} · ${d.time}`:d.message;if(navigator.vibrate)navigator.vibrate(d.ok?120:70);}catch(e){out.className='alert alert-danger scan-result';out.textContent='Koneksi server gagal. Kamera tetap aktif; coba pindai kembali.';}finally{setTimeout(()=>{busy=false;},850);}}
start?.addEventListener('click',async()=>{if(scanner)return;scanner=new Html5Qrcode('qr-reader');try{await scanner.start({facingMode:'environment'},{fps:12,qrbox:{width:260,height:260},aspectRatio:1.0},async(decoded)=>{const now=Date.now();if(busy||(decoded===lastToken&&now-lastAt<1700))return;lastToken=decoded;lastAt=now;await submitToken(decoded);},()=>{});start.disabled=true;start.innerHTML='<i class="bi bi-camera-video"></i> Kamera Aktif';out.className='alert alert-info scan-result';out.textContent='Kamera aktif. Pindai QR satu per satu; kamera tetap menyala setelah setiap pemindaian.';}catch(e){scanner=null;out.className='alert alert-danger scan-result';out.textContent='Kamera gagal dibuka. Pastikan izin kamera aktif dan gunakan localhost/HTTPS.';}});window.addEventListener('beforeunload',()=>{if(scanner)scanner.stop().catch(()=>{});});})();</script>
<?php require '../includes/footer.php'; ?>