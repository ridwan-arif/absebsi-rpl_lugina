-- ABSENSI RPL V10.0: additive migration only; existing tables and records are preserved.
CREATE TABLE IF NOT EXISTS pkl_attendance_batches (
 id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
 group_id BIGINT UNSIGNED NOT NULL,
 attendance_date DATE NOT NULL,
 session_kind ENUM('checkin','checkout') NOT NULL,
 photo_path VARCHAR(255) NOT NULL,
 submitted_at DATETIME NOT NULL,
 submitted_by VARCHAR(150) NOT NULL,
 INDEX idx_pkl_batch_group_date (group_id, attendance_date),
 INDEX idx_pkl_batch_date (attendance_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS pkl_attendance_batch_items (
 id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
 batch_id BIGINT UNSIGNED NOT NULL,
 attendance_id BIGINT UNSIGNED NOT NULL,
 placement_id BIGINT UNSIGNED NOT NULL,
 UNIQUE KEY uq_pkl_batch_attendance (batch_id, attendance_id),
 INDEX idx_pkl_batch_item_placement (placement_id),
 CONSTRAINT fk_pkl_batch_item_batch FOREIGN KEY (batch_id) REFERENCES pkl_attendance_batches(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
