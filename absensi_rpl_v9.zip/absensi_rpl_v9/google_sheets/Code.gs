// ABSENSI RPL - Apps Script untuk Spreadsheet milik sekolah (real-time, 1 tab per hari).
const SPREADSHEET_ID = '1YzCqUpqg9rCy2u4wHeSUzlpJbbHOWt53lfJlpQYiYN0';
const SHARED_SECRET = 'RPL-8A856832594802DE65C3626F298183EB'; // Harus sama dengan GOOGLE_SHEETS_SECRET di config/sheets.php.
const ALSO_MASTER = false; // true = selain tab harian, semua absensi juga dicatat di satu tab "Absensi" (rekap).

const HARI = ['Minggu','Senin','Selasa','Rabu','Kamis','Jumat','Sabtu'];
const BULAN = ['Januari','Februari','Maret','April','Mei','Juni','Juli','Agustus','September','Oktober','November','Desember'];
const HEADER = ['Event ID','Waktu Catat','Tanggal','Jam','ID Database','ID RPL','Kolom Lama (abaikan)','Nama Siswa','Kelas','Sesi','Jenis Absensi','Metode','Petugas'];

function json(data){return ContentService.createTextOutput(JSON.stringify(data)).setMimeType(ContentService.MimeType.JSON);}
function doGet(){return json({ok:true,app:'ABSENSI RPL',spreadsheet_id:SPREADSHEET_ID});}

// "2026-11-09" -> "Senin, 09-November-2026"
function dayTabName(dateStr){
 const m=/^(\d{4})-(\d{2})-(\d{2})/.exec(String(dateStr||''));
 if(!m) return 'Tanpa Tanggal';
 const y=+m[1],mo=+m[2],d=+m[3];
 const dow=new Date(Date.UTC(y,mo-1,d)).getUTCDay();
 return HARI[dow]+', '+m[3]+'-'+BULAN[mo-1]+'-'+y;
}

function getOrCreateTab(ss,name){
 let sh=ss.getSheetByName(name);
 if(sh) return sh;
 sh=ss.insertSheet(name,0); // tab hari terbaru di paling kiri
 sh.appendRow(HEADER);sh.setFrozenRows(1);
 sh.getRange(1,1,1,HEADER.length).setFontWeight('bold').setBackground('#a2f3f8');
 return sh;
}

function appendOnce(sh,eventId,row){
 if(eventId&&sh.getLastRow()>1){
  const ids=sh.getRange(2,1,sh.getLastRow()-1,1).getValues().flat();
  if(ids.includes(eventId)) return false;
 }
 sh.appendRow(row);
 return true;
}

function doPost(e){
 const lock=LockService.getScriptLock();
 try{
  lock.waitLock(20000); // cegah baris bertabrakan saat banyak siswa absen bersamaan
  const data=JSON.parse((e&&e.postData&&e.postData.contents)||'{}');
  if(data.secret!==SHARED_SECRET)return json({ok:false,error:'unauthorized'});
  if(data.action==='ping')return json({ok:true,pong:true});
  const ss=SpreadsheetApp.openById(SPREADSHEET_ID);
  if(data.action==='sync_students'){
   const sh=ss.getSheetByName('Data Siswa')||ss.insertSheet('Data Siswa');
   const header=['ID RPL','Nama','Kelas','Jabatan','Status'];
   const values=[header].concat((data.students||[]).map(s=>[s.id_rpl,s.name,s.class_name,s.position,s.status==='active'?'Aktif':'Nonaktif']));
   sh.clearContents();if(values.length)sh.getRange(1,1,values.length,header.length).setValues(values);
   sh.setFrozenRows(1);sh.getRange(1,1,1,header.length).setFontWeight('bold').setBackground('#a2f3f8');
   return json({ok:true,rows:values.length-1,tab:'Data Siswa'});
  }
  const eventId=String(data.event_id||'');
  const dateStr=data.date||String(data.recorded_at||'').substring(0,10)||Utilities.formatDate(new Date(),Session.getScriptTimeZone(),'yyyy-MM-dd');
  const row=[eventId,data.recorded_at||'',dateStr,data.time||'',data.student_id||'',data.id_rpl||'','',data.student_name||'',data.class_name||'',data.session_name||'',data.attendance_type||'',data.method||'',data.operator||''];
  const tab=dayTabName(dateStr);
  const added=appendOnce(getOrCreateTab(ss,tab),eventId,row);
  if(ALSO_MASTER){
   const ms=ss.getSheetByName('Absensi')||ss.insertSheet('Absensi');
   if(ms.getLastRow()===0){ms.appendRow(HEADER);ms.setFrozenRows(1);ms.getRange(1,1,1,HEADER.length).setFontWeight('bold').setBackground('#a2f3f8');}
   appendOnce(ms,eventId,row);
  }
  SpreadsheetApp.flush();
  return json(added?{ok:true,tab:tab}:{ok:true,duplicate:true,tab:tab});
 }catch(err){return json({ok:false,error:String(err)});}
 finally{try{lock.releaseLock();}catch(x){}}
}
