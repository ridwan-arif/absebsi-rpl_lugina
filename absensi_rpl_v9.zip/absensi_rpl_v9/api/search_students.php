<?php
require_once __DIR__ . '/../includes/auth.php';
require_role(['petugas','admin']);
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
try {
    $q = trim((string)($_GET['q'] ?? ''));
    if ($q === '') { echo json_encode([]); exit; }
    $stmt = $pdo->prepare("SELECT s.id, s.nis AS id_rpl, s.full_name, s.qr_token, c.class_name
        FROM students s JOIN classes c ON c.id=s.class_id
        WHERE s.status='active' AND (s.nis LIKE :code OR s.full_name LIKE :name OR CAST(s.id AS CHAR)=:internal_id)
        ORDER BY CASE WHEN s.nis=:exact_code THEN 0 ELSE 1 END, s.full_name LIMIT 20");
    $stmt->execute([':code' => "%{$q}%", ':name' => "%{$q}%", ':internal_id' => $q, ':exact_code' => $q]);
    echo json_encode($stmt->fetchAll(), JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
} catch (Throwable $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Pencarian siswa gagal. Periksa koneksi database.']);
}
