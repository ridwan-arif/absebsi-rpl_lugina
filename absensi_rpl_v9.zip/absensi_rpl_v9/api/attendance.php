<?php
require_once __DIR__ . '/../includes/auth.php'; require_role(['petugas','admin']);
header('Content-Type: application/json; charset=utf-8');
try {
    $token=trim((string)($_POST['token']??'')); $sessionId=(int)($_POST['session_id']??0); $type=(string)($_POST['type']??''); $method=(string)($_POST['method']??'qr');
    if($token===''||$sessionId<1){http_response_code(422);echo json_encode(['ok'=>false,'message'=>'Data absensi belum lengkap.']);exit;}
    $result=record_attendance($pdo,$token,$sessionId,$type,$method);
    if($result['ok']) {
        log_activity($pdo,'ATTENDANCE_'.strtoupper($result['type'] ?? $type),strtoupper($method).' · '.$result['student']['nis'].' · '.$result['student']['full_name']);
        echo json_encode(['ok'=>true,'message'=>$result['message'],'student'=>$result['student']['full_name'],'id_rpl'=>$result['student']['nis'],'time'=>$result['time'],'type'=>$result['type']],JSON_UNESCAPED_UNICODE);
    } else { http_response_code(400); echo json_encode($result,JSON_UNESCAPED_UNICODE); }
} catch(Throwable $e) { http_response_code(500); echo json_encode(['ok'=>false,'message'=>'Server gagal memproses absensi. Periksa log PHP/MySQL.']); }
