<?php
require_once '../includes/auth.php'; require_role(['admin']);
require_once '../config/sheets.php';
header('Content-Type: application/json; charset=utf-8');
$result=sync_pending_sheets($pdo,100);
echo json_encode($result,JSON_UNESCAPED_UNICODE);
