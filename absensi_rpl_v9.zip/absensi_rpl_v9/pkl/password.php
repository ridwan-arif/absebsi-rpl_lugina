<?php
require_once '../includes/pkl_auth.php'; require_pkl_student();
$error='';$success='';
if($_SERVER['REQUEST_METHOD']==='POST'){
 csrf_check();$old=$_POST['old_password']??'';$new=$_POST['new_password']??'';$confirm=$_POST['confirm_password']??'';
 $q=$pdo->prepare('SELECT password_hash FROM student_accounts WHERE student_id=? AND status=\'active\'');$q->execute([$_SESSION['pkl_student_id']]);$hash=$q->fetchColumn();
 if(!$hash||!password_verify($old,$hash))$error='Password lama tidak sesuai.';
 elseif(strlen($new)<8)$error='Password baru minimal 8 karakter.';
 elseif($new!==$confirm)$error='Konfirmasi password tidak sama.';
 else{$q=$pdo->prepare('UPDATE student_accounts SET password_hash=?,updated_at=NOW() WHERE student_id=?');$q->execute([password_hash($new,PASSWORD_DEFAULT),$_SESSION['pkl_student_id']]);pkl_log($pdo,'CHANGE_PASSWORD','Siswa mengganti password');$success='Password berhasil diperbarui.';}
}
$page_title='Ganti Password';require '../includes/header.php'; ?>
<div class="page-heading"><div><h1 class="page-title">Ganti Password</h1><p class="page-subtitle">Jaga kerahasiaan akun PKL Anda.</p></div></div>
<div class="panel" style="max-width:620px"><?php if($error): ?><div class="alert alert-danger"><?= e($error) ?></div><?php endif; ?><?php if($success): ?><div class="alert alert-success"><?= e($success) ?></div><?php endif; ?><form method="post"><input type="hidden" name="_csrf" value="<?= e(csrf_token()) ?>"><label class="form-label">Password lama</label><input type="password" name="old_password" class="form-control mb-3" required><label class="form-label">Password baru</label><input type="password" name="new_password" class="form-control mb-3" minlength="8" required><label class="form-label">Konfirmasi password baru</label><input type="password" name="confirm_password" class="form-control mb-3" minlength="8" required><button class="btn btn-primary">Simpan Password</button></form></div><?php require '../includes/footer.php'; ?>
