<?php
require_once __DIR__.'/config/database.php';
$count=(int)$pdo->query("SELECT COUNT(*) FROM users")->fetchColumn();
if ($count===0) {
    $hash=password_hash('AdminRPL!2026',PASSWORD_DEFAULT);
    $pdo->prepare("INSERT INTO users(full_name,username,password_hash,role,status) VALUES(?,?,?,'admin','active')")
        ->execute(['Administrator RPL','admin',$hash]);
    echo 'Admin V4 berhasil dibuat.<br>Username: admin<br>Password: AdminRPL!2026<br><b>Segera login lalu ubah password. Hapus setup.php setelah selesai.</b>';
} else echo 'Tabel users sudah berisi akun. Setup dilewati. Hapus setup.php.';
