<?php
// ===== PENGATURAN GOOGLE SHEETS (REAL-TIME) =====
// 1) Deploy google_sheets/Code.gs sebagai Web App, lalu tempel URL berakhiran /exec di bawah ini.
define('GOOGLE_SHEETS_WEBHOOK', 'https://script.google.com/macros/s/AKfycbwvvq40S-f7JhLsNtkFEHYPc2i1CpX2UKShKHFBWUoptxQ8_L8VQd7JLgzXBSNKsByy/exec');
define('GOOGLE_SHEETS_ID', '1YzCqUpqg9rCy2u4wHeSUzlpJbbHOWt53lfJlpQYiYN0');
// 2) Token rahasia: HARUS sama persis dengan SHARED_SECRET di Code.gs.
define('GOOGLE_SHEETS_SECRET', 'RPL-8A856832594802DE65C3626F298183EB');
// 3) Jika di XAMPP muncul galat "SSL certificate problem", perbaiki curl.cainfo di php.ini.
//    Hanya untuk percobaan lokal, boleh ubah menjadi false (kurang aman).
define('GOOGLE_SHEETS_SSL_VERIFY', true);

function queue_sheet_event(PDO $pdo, int $attendanceId, array $payload): int {
 $stmt=$pdo->prepare("INSERT INTO sheet_sync_queue(attendance_id,payload_json,status,attempts,created_at) VALUES(?,?,'pending',0,NOW())");
 $stmt->execute([$attendanceId,json_encode($payload,JSON_UNESCAPED_UNICODE)]);
 return (int)$pdo->lastInsertId();
}

function sheets_post(array $payload): array {
 if(GOOGLE_SHEETS_WEBHOOK==='') return ['ok'=>false,'message'=>'URL Apps Script belum dipasang.'];
 $payload['secret']=GOOGLE_SHEETS_SECRET;
 $body=json_encode($payload,JSON_UNESCAPED_UNICODE);
 $response=false;$http=0;$err='';
 if(function_exists('curl_init')){
  // Apps Script membalas 302 lalu hasilnya diambil dengan GET; cURL menanganinya otomatis.
  $ch=curl_init(GOOGLE_SHEETS_WEBHOOK);
  curl_setopt_array($ch,[CURLOPT_POST=>true,CURLOPT_POSTFIELDS=>$body,CURLOPT_HTTPHEADER=>['Content-Type: application/json'],
   CURLOPT_RETURNTRANSFER=>true,CURLOPT_FOLLOWLOCATION=>true,CURLOPT_MAXREDIRS=>5,CURLOPT_CONNECTTIMEOUT=>5,CURLOPT_TIMEOUT=>20,
   CURLOPT_SSL_VERIFYPEER=>GOOGLE_SHEETS_SSL_VERIFY,CURLOPT_SSL_VERIFYHOST=>GOOGLE_SHEETS_SSL_VERIFY?2:0]);
  $response=curl_exec($ch);$http=(int)curl_getinfo($ch,CURLINFO_HTTP_CODE);$err=curl_error($ch);curl_close($ch);
 } else {
  $ctx=stream_context_create(['http'=>['method'=>'POST','header'=>"Content-Type: application/json\r\n",'content'=>$body,'timeout'=>20,'ignore_errors'=>true,'follow_location'=>1]]);
  $response=@file_get_contents(GOOGLE_SHEETS_WEBHOOK,false,$ctx);
 }
 if($response===false||$response===''){return ['ok'=>false,'message'=>'Tidak ada respons dari Google'.($err?" ($err)":'').'.'];}
 $data=json_decode($response,true);
 if(!is_array($data)){return ['ok'=>false,'message'=>'Respons bukan JSON (HTTP '.$http.'). Pastikan akses Web App = Anyone dan URL berakhiran /exec.'];}
 if(!empty($data['ok'])) return ['ok'=>true,'message'=>'Terkirim','data'=>$data];
 return ['ok'=>false,'message'=>(($data['error']??'')==='unauthorized')?'Token ditolak: SHARED_SECRET di Apps Script berbeda dengan config/sheets.php.':('Ditolak Apps Script: '.($data['error']??'tidak diketahui'))];
}

function sheets_test(): array { return sheets_post(['action'=>'ping']); }

function sync_queue_row(PDO $pdo,int $queueId): bool {
 $q=$pdo->prepare("SELECT * FROM sheet_sync_queue WHERE id=? AND status IN ('pending','failed')");$q->execute([$queueId]);$row=$q->fetch();
 if(!$row) return false;
 $result=sheets_post(json_decode($row['payload_json'],true)?:[]);
 if($result['ok']){$pdo->prepare("UPDATE sheet_sync_queue SET status='sent',attempts=attempts+1,sent_at=NOW(),last_error=NULL WHERE id=?")->execute([$row['id']]);return true;}
 $pdo->prepare("UPDATE sheet_sync_queue SET status='failed',attempts=attempts+1,last_error=? WHERE id=?")->execute([$result['message'],$row['id']]);
 return false;
}

function sync_pending_sheets(PDO $pdo,int $limit=30,int $maxAttempts=8): array {
 if(GOOGLE_SHEETS_WEBHOOK==='') return ['sent'=>0,'pending'=>true,'message'=>'URL Google Sheets belum diatur.'];
 $q=$pdo->prepare("SELECT id FROM sheet_sync_queue WHERE status IN ('pending','failed') AND attempts<? ORDER BY id ASC LIMIT ?");
 $q->bindValue(1,$maxAttempts,PDO::PARAM_INT);$q->bindValue(2,$limit,PDO::PARAM_INT);$q->execute();$sent=0;$fail=0;
 foreach($q->fetchAll() as $row){ if(sync_queue_row($pdo,(int)$row['id'])) $sent++; else {$fail++; if($fail>=3) break;} }
 return ['sent'=>$sent,'pending'=>false,'message'=>$sent?"{$sent} catatan absensi berhasil dikirim.":($fail?'Pengiriman gagal. Lihat pesan galat di halaman Pengaturan.':'Tidak ada antrean yang perlu dikirim.')];
}

function sync_student_roster_to_sheets(PDO $pdo): array {
 $rows=$pdo->query("SELECT s.id AS student_id,s.nis AS id_rpl,s.full_name AS name,c.class_name AS class_name,s.student_role AS position,s.status FROM students s JOIN classes c ON c.id=s.class_id ORDER BY c.id,s.full_name")->fetchAll();
 return sheets_post(['action'=>'sync_students','students'=>$rows,'synced_at'=>date('Y-m-d H:i:s')]);
}
