<?php
require_once __DIR__ . '/app.php';
$host = '127.0.0.1';
$port = '3306';
$dbname = 'absensi_rpl_v4';
$dbuser = 'root';
$dbpass = '';
try {
    $pdo = new PDO(
        "mysql:host={$host};port={$port};dbname={$dbname};charset=utf8mb4",
        $dbuser,
        $dbpass,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]
    );
    $pdo->exec("SET time_zone = '+07:00'");
} catch (PDOException $e) {
    http_response_code(500);
    exit('Database belum siap. Pastikan database absensi_rpl_v4 tersedia dan periksa config/database.php. Detail: ' . htmlspecialchars($e->getMessage()));
}
