<?php
declare(strict_types=1);
define('APP_NAME', 'ABSENSI RPL V10.1');
define('APP_VERSION', '10.1.0');
define('APP_BASE_URL', '/absensi_rpl_v9'); // Folder instalasi V9.
date_default_timezone_set('Asia/Jakarta');

if (!defined('APP_KEY')) define('APP_KEY', 'v8-absensi-rpl-smk-lugina-2026-change-this-secret-before-production');
