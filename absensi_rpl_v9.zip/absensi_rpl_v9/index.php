<?php
require_once __DIR__.'/config/app.php';
header('Location: '.APP_BASE_URL.'/auth/login.php');
exit;
