<?php
session_start();
if (!empty($_SESSION['user_id'])) { require_once __DIR__.'/../config/database.php'; require_once __DIR__.'/../includes/functions.php'; log_activity($pdo,'LOGOUT','Pengguna keluar dari sistem'); }
if (!empty($_SESSION['pkl_group_id'])) { require_once __DIR__.'/../config/database.php'; $q=$pdo->prepare("INSERT INTO pkl_activity_logs(student_id,action,detail,ip_address) VALUES(?,?,?,?)"); $q->execute([null,'GROUP_LOGOUT','Koordinator keluar',$_SERVER['REMOTE_ADDR']??null]); }
if (!empty($_SESSION['pkl_student_id'])) { require_once __DIR__.'/../config/database.php'; $q=$pdo->prepare("INSERT INTO pkl_activity_logs(student_id,action,detail,ip_address) VALUES(?,?,?,?)"); $q->execute([$_SESSION['pkl_student_id'],'LOGOUT','Siswa keluar',$_SERVER['REMOTE_ADDR']??null]); }
$_SESSION=[]; session_destroy(); header('Location: '.APP_BASE_URL.'/auth/login.php'); exit;
