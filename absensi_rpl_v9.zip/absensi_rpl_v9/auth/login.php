<?php
session_start();
require_once __DIR__.'/../config/database.php';
require_once __DIR__.'/../includes/functions.php';
$error='';
if ($_SERVER['REQUEST_METHOD']==='POST') {
    csrf_check();
    $username=trim((string)($_POST['username']??'')); $password=(string)($_POST['password']??'');
    $stmt=$pdo->prepare("SELECT * FROM users WHERE username=? AND status='active' LIMIT 1");
    $stmt->execute([$username]); $user=$stmt->fetch();
    if ($user && password_verify($password,$user['password_hash'])) {
        session_regenerate_id(true);
        $_SESSION['user_id']=(int)$user['id']; $_SESSION['full_name']=$user['full_name']; $_SESSION['role']=$user['role'];
        unset($_SESSION['pkl_group_id'],$_SESSION['pkl_group_name'],$_SESSION['pkl_coordinator_name']);
        log_activity($pdo,'LOGIN','Pengguna masuk ke sistem');
        redirect($user['role']==='admin'?'admin/dashboard.php':'petugas/dashboard.php');
    }
    $q=$pdo->prepare("SELECT g.*,s.full_name coordinator_name,co.company_name FROM pkl_groups g JOIN students s ON s.id=g.coordinator_student_id JOIN pkl_companies co ON co.id=g.company_id WHERE g.username=? AND g.status='active' AND co.status='active' LIMIT 1");
    $q->execute([$username]); $g=$q->fetch();
    if($g && password_verify($password,$g['password_hash'])) {
        session_regenerate_id(true);
        $_SESSION['pkl_group_id']=(int)$g['id']; $_SESSION['pkl_group_name']=$g['group_name']; $_SESSION['pkl_coordinator_name']=$g['coordinator_name']; $_SESSION['pkl_username']=$g['username'];
        $pdo->prepare("INSERT INTO pkl_activity_logs(student_id,action,detail,ip_address) VALUES(?,?,?,?)")->execute([$g['coordinator_student_id'],'GROUP_LOGIN','Koordinator '.$g['group_name'],$_SERVER['REMOTE_ADDR']??null]);
        redirect('pkl/coordinator.php');
    }
    $error='Username atau password salah, atau akun tidak aktif.';
}
?><!doctype html><html lang="id"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Login | ABSENSI RPL V10.1</title><link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"><link href="<?= url('assets/css/app.css') ?>" rel="stylesheet"><link href="<?= url('assets/css/motion.css?v=10.1.7') ?>" rel="stylesheet"><link href="<?= url('assets/css/table-hover-fix.css?v=10.1.7') ?>" rel="stylesheet"></head><body class="rpl-login-page d-flex align-items-center justify-content-center min-vh-100 p-3">
<div class="rpl-login-pets" aria-hidden="true"><span class="pet pet-cat">🐱</span><span class="pet pet-dog">🐶</span><span class="pet pet-fox">🦊</span><span class="pet pet-bunny">🐰</span><span class="pet-spark">✦</span></div><div class="rpl-login-card panel w-100" style="max-width:440px;padding:30px"><div class="text-center mb-4"><img src="<?= url('assets/img/logo-rpl.png') ?>" style="width:125px;height:115px;object-fit:contain" alt="Logo RPL"><h3 class="fw-bold mt-2">ABSENSI <span class="rpl-login-accent">RPL</span></h3>
<div class="rpl-login-tagline">CREATE · LEARN · INNOVATE</div><div class="text-muted small">SMK LUGINA RANCAEKEK · VERSI 10.1</div></div><?php if($error): ?><div class="alert alert-danger"><?= e($error) ?></div><?php endif; ?><form method="post"><input type="hidden" name="_csrf" value="<?= e(csrf_token()) ?>"><label class="form-label" for="login-username">Username</label><input id="login-username" class="form-control mb-3" name="username" autocomplete="username" minlength="3" required autofocus><label class="form-label" for="login-password">Password</label><input id="login-password" class="form-control mb-4" type="password" name="password" autocomplete="current-password" minlength="1" required><button class="btn btn-primary w-100 py-2">Masuk ke Sistem</button></form><div class="text-center mt-3 small text-muted">Admin · Petugas · Koordinator PKL</div></div><script src="<?= url('assets/js/motion.js') ?>"></script><style>
.rpl-login-page{position:relative;isolation:isolate;overflow:hidden;background:radial-gradient(ellipse at 20% 20%,#274b7b 0,transparent 38%),radial-gradient(ellipse at 85% 75%,#49316f 0,transparent 34%),linear-gradient(145deg,#0a1224,#14243d 58%,#10172c)}
.rpl-login-card{position:relative;z-index:2;border:1px solid #a9dfff55!important;border-radius:28px!important;background:linear-gradient(145deg,rgba(31,48,77,.96),rgba(19,30,51,.97))!important;box-shadow:0 28px 90px #02081799,0 0 38px #56c9ef22!important;backdrop-filter:blur(18px);animation:login-card-in .8s cubic-bezier(.2,.8,.2,1) both}
.rpl-login-card .form-label{color:#d8e7fa}.rpl-login-card .text-muted,.rpl-login-card .small{color:#b3c5df!important}
.rpl-login-card .form-control{background:#0e1a2e;color:#fff;border:1px solid #526987;border-radius:13px;padding:12px 14px}
.rpl-login-card .form-control:focus{border-color:#76e1f4;box-shadow:0 0 0 4px #65d5ee22,0 0 20px #65d5ee22}
.rpl-login-card .btn-primary{border-radius:14px;padding:13px!important}
.rpl-login-card a{color:#8ce7f5}
.rpl-login-accent{color:#7edff1}.rpl-login-tagline{font-size:.65rem;letter-spacing:.2em;color:#9fc4ed;font-weight:800}
.rpl-login-pets{position:absolute;inset:0;z-index:1;pointer-events:none;overflow:hidden}
.pet{position:absolute;font-size:clamp(2rem,5vw,4rem);filter:drop-shadow(0 8px 14px #0005);animation:pet-float 6s ease-in-out infinite}
.pet-cat{left:8%;top:20%}.pet-dog{right:9%;top:25%;animation-delay:-1.7s}.pet-fox{left:13%;bottom:14%;animation-delay:-3s}.pet-bunny{right:13%;bottom:12%;animation-delay:-4.1s}
.pet-spark{position:absolute;left:50%;top:9%;font-size:2rem;color:#a6f0ff;text-shadow:0 0 20px #7de8ff;animation:pet-twinkle 2.5s ease-in-out infinite}
@keyframes pet-float{0%,100%{transform:translateY(0) rotate(-7deg)}50%{transform:translateY(-18px) rotate(7deg)}}
@keyframes pet-twinkle{0%,100%{opacity:.3;transform:scale(.7) rotate(0)}50%{opacity:1;transform:scale(1.2) rotate(90deg)}}
@keyframes login-card-in{from{opacity:0;transform:translateY(22px) scale(.97)}to{opacity:1;transform:none}}
@media(max-width:600px){.pet-cat{left:2%;top:8%}.pet-dog{right:2%;top:10%}.pet-fox{left:2%;bottom:5%}.pet-bunny{right:2%;bottom:5%}.pet{font-size:2rem}}
@media(prefers-reduced-motion:reduce){.pet,.pet-spark,.rpl-login-card{animation:none}}
</style>
</body></html>